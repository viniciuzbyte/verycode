# No aggressive shrinking needed for this build.
