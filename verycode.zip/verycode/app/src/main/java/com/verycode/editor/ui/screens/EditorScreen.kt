package com.verycode.editor.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import com.verycode.editor.ui.components.BottomAction
import com.verycode.editor.ui.components.CodeSymbolBar
import com.verycode.editor.ui.components.FileTypeIcon
import com.verycode.editor.ui.components.HtmlPreview
import java.io.BufferedReader
import java.io.InputStreamReader

@Composable
fun EditorScreen(
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    var currentUri by remember { mutableStateOf<Uri?>(null) }
    var currentName by remember { mutableStateOf("index.html") }
    var code by remember { mutableStateOf(DEFAULT_HTML) }
    var selectedFolder by remember { mutableStateOf<Uri?>(null) }
    var folderFiles by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var previewMode by remember { mutableStateOf(false) }
    var showFolderDrawer by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("") }

    val lineCount = remember(code) { code.lines().size.coerceAtLeast(1) }

    fun refreshFolder() {
        val uri = selectedFolder ?: return
        val folder = DocumentFile.fromTreeUri(context, uri)
        folderFiles = folder?.listFiles()?.sortedBy { it.name?.lowercase() ?: "" }?.toList() ?: emptyList()
    }

    fun openDocument(uri: Uri) {
        try {
            val text = context.contentResolver.openInputStream(uri)?.use {
                BufferedReader(InputStreamReader(it)).readText()
            } ?: ""
            currentUri = uri
            currentName = DocumentFile.fromSingleUri(context, uri)?.name ?: "Untitled"
            code = text
            previewMode = false
            showFolderDrawer = false
            notice = "Opened $currentName"
        } catch (error: Exception) {
            notice = "Err: ${error.message}"
        }
    }

    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}
            openDocument(uri)
        }
    }

    val chooseFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}
            selectedFolder = uri
            refreshFolder()
            showFolderDrawer = true
            notice = "Folder connected"
        }
    }

    fun saveFile() {
        val uri = currentUri
        if (uri == null) {
            notice = "Save not target uri"
            return
        }
        try {
            context.contentResolver.openOutputStream(uri, "wt")?.use {
                it.write(code.toByteArray(Charsets.UTF_8))
            }
            notice = "File saved"
            refreshFolder()
        } catch (error: Exception) {
            notice = "Save failed: ${error.message}"
        }
    }

    fun createInFolder(extension: String) {
        val tree = selectedFolder
        if (tree == null) {
            chooseFolder.launch(null)
            return
        }
        try {
            val folder = DocumentFile.fromTreeUri(context, tree)
            val mime = when (extension) {
                "html" -> "text/html"
                "css" -> "text/css"
                "js" -> "text/javascript"
                else -> "text/plain"
            }
            val name = when (extension) {
                "html" -> "index.html"
                "css" -> "style.css"
                "js" -> "script.js"
                else -> "app.txt"
            }
            val file = folder?.createFile(mime, name)
            if (file != null) {
                currentUri = file.uri
                currentName = file.name ?: name
                code = when (extension) {
                    "html" -> DEFAULT_HTML
                    "css" -> "/* VeryCode CSS */\n* {\n  box-sizing: border-box;\n}\n"
                    "js" -> "// VeryCode JS\nconsole.log('VeryCode ready');\n"
                    else -> ""
                }
                context.contentResolver.openOutputStream(file.uri, "wt")?.use {
                    it.write(code.toByteArray(Charsets.UTF_8))
                }
                previewMode = false
                showFolderDrawer = false
                refreshFolder()
                notice = "Created $name"
            }
        } catch (error: Exception) {
            notice = "Failed: ${error.message}"
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "V",
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 15.sp
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "VeryCode",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(Modifier.weight(1f))

                    IconButton(
                        onClick = { showFolderDrawer = !showFolderDrawer },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.Default.Folder,
                            contentDescription = "Project",
                            tint = if (showFolderDrawer) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(
                        onClick = { openFile.launch(arrayOf("*/*")) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.Default.FileOpen,
                            contentDescription = "Open File",
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FileTypeIcon(currentName)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = currentName,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                        )
                    }

                    Spacer(Modifier.weight(1f))

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (previewMode) MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                                else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (previewMode) "LIVE PREVIEW" else "KODE",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (previewMode) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.8.sp
                        )
                    }
                }
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .navigationBarsPadding()
            ) {
                if (!previewMode) {
                    CodeSymbolBar(onSymbolClick = { symbol ->
                        code += symbol
                    })
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BottomAction("Simpan", Icons.Default.Save) { saveFile() }
                    BottomAction(
                        if (previewMode) "Editor" else "Jalankan",
                        if (previewMode) Icons.Default.Code else Icons.Default.PlayArrow
                    ) {
                        if (previewMode) {
                            previewMode = false
                        } else {
                            saveFile()
                            previewMode = true
                        }
                    }
                    BottomAction("Browser", Icons.Default.OpenInBrowser) {
                        saveFile()
                        currentUri?.let { uri ->
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, "text/html")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            try {
                                context.startActivity(Intent.createChooser(intent, "Buka di Browser"))
                            } catch (_: Exception) {}
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                if (showFolderDrawer) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        tonalElevation = 6.dp
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "EXPLORER PROYEK",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = { createInFolder("html") }) { Text("+ HTML", fontSize = 11.sp) }
                                TextButton(onClick = { createInFolder("css") }) { Text("+ CSS", fontSize = 11.sp) }
                                TextButton(onClick = { createInFolder("js") }) { Text("+ JS", fontSize = 11.sp) }
                            }

                            if (folderFiles.isEmpty()) {
                                Text(
                                    "Belum ada folder terpilih. Tekan ikon folder di atas untuk menghubungkan direktori.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            } else {
                                LazyColumn(modifier = Modifier.heightIn(max = 150.dp)) {
                                    items(folderFiles) { file ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(6.dp))
                                                .clickable { openDocument(file.uri) }
                                                .padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            FileTypeIcon(file.name ?: "file")
                                            Spacer(Modifier.width(8.dp))
                                            Text(
                                                file.name ?: "Untitled",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (previewMode) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                    ) {
                        HtmlPreview(code, currentUri?.toString())
                    }
                } else {
                    val verticalScroll = rememberScrollState()
                    val horizontalScroll = rememberScrollState()

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(verticalScroll)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                        .padding(horizontal = 10.dp, vertical = 12.dp),
                                    horizontalAlignment = Alignment.End
                                ) {
                                    for (i in 1..lineCount) {
                                        Text(
                                            text = "$i",
                                            fontSize = 12.sp,
                                            lineHeight = 20.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                                        )
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .horizontalScroll(horizontalScroll)
                                        .padding(horizontal = 12.dp, vertical = 12.dp)
                                ) {
                                    BasicTextField(
                                        value = code,
                                        onValueChange = { code = it },
                                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                                        textStyle = TextStyle(
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontSize = 12.sp,
                                            lineHeight = 20.sp,
                                            fontFamily = FontFamily.Monospace
                                        ),
                                        decorationBox = { inner ->
                                            if (code.isEmpty()) {
                                                Text(
                                                    "Tulis kode HTML/CSS/JS di sini...",
                                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                                                    fontFamily = FontFamily.Monospace,
                                                    fontSize = 12.sp
                                                )
                                            }
                                            inner()
                                        }
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (notice.isNotBlank()) notice else "UTF-8 • Ln $lineCount",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                            Spacer(Modifier.weight(1f))
                            Text(
                                text = "HTML/CSS/JS",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

private const val DEFAULT_HTML = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>VeryCode App</title>
  <style>
    body {
      margin: 0;
      padding: 32px;
      font-family: system-ui, -apple-system, sans-serif;
      background: #0f172a;
      color: #f8fafc;
    }
    h1 { color: #10b981; }
  </style>
</head>
<body>
  <h1>Halo dari VeryCode!</h1>
  <p>Workspace web modern buatan Faddlan.</p>
</body>
</html>
"""
