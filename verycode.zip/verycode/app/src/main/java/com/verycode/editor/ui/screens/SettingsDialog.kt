package com.verycode.editor.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.verycode.editor.data.AppTheme

@Composable
fun SettingsDialog(
    currentTheme: AppTheme,
    onThemeChanged: (AppTheme) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Settings & About", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("Appearance", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(8.dp))
                
                ThemeChoiceRow("System Default", currentTheme == AppTheme.SYSTEM) { onThemeChanged(AppTheme.SYSTEM) }
                ThemeChoiceRow("Dark Mode", currentTheme == AppTheme.DARK) { onThemeChanged(AppTheme.DARK) }
                ThemeChoiceRow("Light Mode", currentTheme == AppTheme.LIGHT) { onThemeChanged(AppTheme.LIGHT) }

                Spacer(Modifier.height(18.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                Spacer(Modifier.height(14.dp))

                Text("About VeryCode", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(4.dp))
                Text("Version: 1.0.0", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                Text("Creator: Faddlan", fontWeight = FontWeight.Medium, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                Text("A mobile-first web code editor built with Jetpack Compose.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
private fun ThemeChoiceRow(
    label: String,
    selected: Boolean,
    onSelect: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onSelect)
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 13.sp)
    }
}
