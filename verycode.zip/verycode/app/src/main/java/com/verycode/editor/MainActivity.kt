package com.verycode.editor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import com.verycode.editor.data.AppPreferences
import com.verycode.editor.data.AppTheme
import com.verycode.editor.ui.screens.EditorScreen
import com.verycode.editor.ui.screens.OnboardingScreen
import com.verycode.editor.ui.screens.SettingsDialog
import com.verycode.editor.ui.theme.VeryCodeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val prefs = AppPreferences(this)

        setContent {
            var hasCompletedOnboarding by remember { mutableStateOf(prefs.hasCompletedOnboarding) }
            var currentTheme by remember { mutableStateOf(prefs.selectedTheme) }
            var showSettingsDialog by remember { mutableStateOf(false) }

            VeryCodeTheme(themeSetting = currentTheme) {
                if (!hasCompletedOnboarding) {
                    OnboardingScreen(
                        onFinished = { chosenTheme ->
                            prefs.selectedTheme = chosenTheme
                            prefs.hasCompletedOnboarding = true
                            currentTheme = chosenTheme
                            hasCompletedOnboarding = true
                        }
                    )
                } else {
                    EditorScreen(
                        onOpenSettings = { showSettingsDialog = true }
                    )

                    if (showSettingsDialog) {
                        SettingsDialog(
                            currentTheme = currentTheme,
                            onThemeChanged = { newTheme ->
                                prefs.selectedTheme = newTheme
                                currentTheme = newTheme
                            },
                            onDismiss = { showSettingsDialog = false }
                        )
                    }
                }
            }
        }
    }
}
