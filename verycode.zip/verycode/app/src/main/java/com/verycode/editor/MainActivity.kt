package com.verycode.editor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import com.caverock.androidsvg.SVG
import java.io.BufferedReader
import java.io.InputStreamReader

private val CanvasBg = Color(0xFFF3F5F4)
private val SurfaceWhite = Color(0xFFFFFFFF)
private val Ink = Color(0xFF202C2B)
private val Muted = Color(0xFF75827F)
private val Teal = Color(0xFF287D78)
private val Line = Color(0xFFE2E8E5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(243, 245, 244)
        window.navigationBarColor = android.graphics.Color.rgb(243, 245, 244)
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContent { VeryCodeApp() }
    }
}

@Composable
private fun VeryCodeApp() {
    val context = LocalContext.current
    var currentUri by remember { mutableStateOf<Uri?>(null) }
    var currentName by remember { mutableStateOf("Welcome") }
    var code by remember { mutableStateOf(defaultHtml) }
    var selectedFolder by remember { mutableStateOf<Uri?>(null) }
    var folderFiles by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var previewMode by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("") }

    fun refreshFolder() {
        val uri = selectedFolder ?: return
        val folder = DocumentFile.fromTreeUri(context, uri)
        folderFiles = folder?.listFiles()?.sortedBy { it.name?.lowercase() ?: "" }?.toList() ?: emptyList()
    }

    fun openDocument(uri: Uri) {
        try {
            val text = context.contentResolver.openInputStream(uri)?.use {
                BufferedReader(InputStreamReader(it)).readText()
            } ?: ""
            currentUri = uri
            currentName = DocumentFile.fromSingleUri(context, uri)?.name ?: "Untitled"
            code = text
            previewMode = false
            notice = "File opened"
        } catch (error: Exception) {
            notice = "Could not open file: ${error.message}"
        }
    }

    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}
            openDocument(uri)
        }
    }

    val createFile = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/html")
    ) { uri ->
        if (uri != null) {
            currentUri = uri
            currentName = DocumentFile.fromSingleUri(context, uri)?.name ?: "index.html"
            code = defaultHtml
            try {
                context.contentResolver.openOutputStream(uri, "wt")?.use {
                    it.write(code.toByteArray(Charsets.UTF_8))
                }
            } catch (_: Exception) {}
            previewMode = false
            notice = "New HTML file created"
        }
    }

    val chooseFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}
            selectedFolder = uri
            refreshFolder()
            notice = "Folder access granted"
        }
    }

    fun saveFile() {
        val uri = currentUri
        if (uri == null) {
            notice = "Open or create a file first"
            return
        }
        try {
            context.contentResolver.openOutputStream(uri, "wt")?.use {
                it.write(code.toByteArray(Charsets.UTF_8))
            }
            notice = "Saved successfully"
            refreshFolder()
        } catch (error: Exception) {
            notice = "Save failed: ${error.message}"
        }
    }

    fun createInFolder(extension: String) {
        val tree = selectedFolder
        val mime = when (extension) {
            "html" -> "text/html"
            "css" -> "text/css"
            "js" -> "text/javascript"
            else -> "text/plain"
        }
        if (tree == null) {
            if (extension == "html") createFile.launch("index.html")
            else notice = "Choose a folder first to create .$extension files"
            return
        }
        try {
            val folder = DocumentFile.fromTreeUri(context, tree)
            val name = when (extension) {
                "html" -> "index.html"
                "css" -> "style.css"
                "js" -> "script.js"
                else -> "notes.txt"
            }
            val file = folder?.createFile(mime, name)
            if (file != null) {
                currentUri = file.uri
                currentName = file.name ?: name
                code = when (extension) {
                    "html" -> defaultHtml
                    "css" -> "body {\\n    margin: 0;\\n    font-family: sans-serif;\\n}"
                    "js" -> "console.log('Hello from VeryCode');"
                    else -> ""
                }
                context.contentResolver.openOutputStream(file.uri, "wt")?.use {
                    it.write(code.toByteArray(Charsets.UTF_8))
                }
                previewMode = false
                refreshFolder()
                notice = "$name created"
            } else {
                notice = "Could not create file"
            }
        } catch (error: Exception) {
            notice = "Create failed: ${error.message}"
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Teal,
            onPrimary = Color.White,
            background = CanvasBg,
            surface = SurfaceWhite,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = CanvasBg,
            topBar = {
                Column(
                    Modifier.fillMaxWidth().background(CanvasBg).padding(horizontal = 18.dp, vertical = 12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("verycode", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text("A calm space to build for the web", fontSize = 11.sp, color = Muted)
                        }
                        IconButton(onClick = { openFile.launch(arrayOf("*/*")) }) {
                            Icon(Icons.Default.FolderOpen, "Open file", tint = Teal)
                        }
                        IconButton(onClick = { chooseFolder.launch(null) }) {
                            Icon(Icons.Default.MoreVert, "Choose folder", tint = Ink)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(
                        Modifier.fillMaxWidth().background(SurfaceWhite, RoundedCornerShape(14.dp)).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Code, null, tint = Teal, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(9.dp))
                        Text(currentName, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.weight(1f))
                        Text(if (previewMode) "PREVIEW" else "EDITOR", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                    }
                }
            },
            bottomBar = {
                Row(
                    Modifier.fillMaxWidth().background(SurfaceWhite).padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BottomAction("Files", Icons.Default.FolderOpen) { previewMode = false; chooseFolder.launch(null) }
                    BottomAction("Add", Icons.Default.Add) { createInFolder("html") }
                    BottomAction("Save", Icons.Default.Save) { saveFile() }
                    BottomAction(if (previewMode) "Code" else "Preview", if (previewMode) Icons.Default.Code else Icons.Default.PlayArrow) {
                        if (previewMode) previewMode = false
                        else {
                            saveFile()
                            previewMode = true
                        }
                    }
                    BottomAction("Chrome", Icons.Default.OpenInBrowser) {
                        saveFile()
                        val uri = currentUri
                        if (uri != null) {
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, "text/html")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            try {
                                context.startActivity(Intent.createChooser(intent, "Open with browser"))
                            } catch (_: Exception) {
                                notice = "No compatible browser found"
                            }
                        }
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                if (notice.isNotBlank()) {
                    Text(notice, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 5.dp))
                }
                if (selectedFolder != null && !previewMode) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("PROJECT FILES", color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { createInFolder("html") }) { Text("+ HTML", color = Teal) }
                        TextButton(onClick = { createInFolder("css") }) { Text("+ CSS", color = Teal) }
                        TextButton(onClick = { createInFolder("js") }) { Text("+ JS", color = Teal) }
                    }
                    LazyColumn(
                        Modifier.fillMaxWidth().heightIn(max = 160.dp).background(SurfaceWhite, RoundedCornerShape(14.dp))
                    ) {
                        items(folderFiles) { file ->
                            Row(
                                Modifier.fillMaxWidth().clickable { openDocument(file.uri) }.padding(horizontal = 12.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                FileTypeIcon(file.name ?: "file")
                                Spacer(Modifier.width(10.dp))
                                Text(file.name ?: "Untitled", color = Ink, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                Text("OPEN", color = Muted, fontSize = 9.sp)
                            }
                            HorizontalDivider(color = Line)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                if (previewMode) {
                    HtmlPreview(code, currentUri?.toString())
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                        Text("EDITOR", color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp, modifier = Modifier.weight(1f))
                        Text("${code.lines().size} lines", color = Muted, fontSize = 10.sp)
                    }
                    Box(
                        Modifier.fillMaxSize().padding(bottom = 8.dp)
                            .background(SurfaceWhite, RoundedCornerShape(16.dp)).padding(14.dp)
                    ) {
                        BasicTextField(
                            value = code,
                            onValueChange = { code = it },
                            modifier = Modifier.fillMaxSize(),
                            textStyle = androidx.compose.ui.text.TextStyle(
                                color = Color(0xFF2B3B3A),
                                fontSize = 13.sp,
                                lineHeight = 20.sp,
                                fontFamily = FontFamily.Monospace
                            ),
                            decorationBox = { inner ->
                                if (code.isEmpty()) Text("Write your code here...", color = Muted, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                                inner()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 5.dp, vertical = 2.dp)
    ) {
        Icon(icon, contentDescription = label, tint = Teal, modifier = Modifier.size(21.dp))
        Text(label, fontSize = 9.sp, color = Ink)
    }
}

@Composable
private fun FileTypeIcon(name: String) {
    val context = LocalContext.current
    val ext = name.substringAfterLast('.', "").lowercase()
    val asset = when (ext) {
        "html", "htm" -> "icons/html.svg"
        "css" -> "icons/css.svg"
        "js", "mjs" -> "icons/javascript.svg"
        else -> "icons/file.svg"
    }
    val bitmap = remember(asset) {
        try {
            val svg = SVG.getFromAsset(context.assets, asset)
            svg.documentWidth = 48f
            svg.documentHeight = 48f
            val image = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            svg.renderToCanvas(Canvas(image))
            image.asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }
    if (bitmap != null) {
        Image(bitmap, contentDescription = "$ext file icon", modifier = Modifier.size(28.dp))
    } else {
        Icon(Icons.Default.Language, null, tint = Teal, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun HtmlPreview(html: String, baseUrl: String?) {
    AndroidView(
        modifier = Modifier.fillMaxSize().background(Color.White, RoundedCornerShape(14.dp)),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.allowFileAccess = true
                settings.allowContentAccess = true
                webChromeClient = WebChromeClient()
                webViewClient = WebViewClient()
            }
        },
        update = { webView ->
            webView.loadDataWithBaseURL(baseUrl ?: "https://verycode.local/", html, "text/html", "UTF-8", null)
        }
    )
}

private val defaultHtml = """<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>VeryCode Preview</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 32px; color: #202c2b; }
        h1 { color: #287d78; }
    </style>
</head>
<body>
    <h1>Hello, VeryCode!</h1>
    <p>Your web project starts here.</p>
    <script>
        console.log("VeryCode is ready");
    </script>
</body>
</html>
"""
