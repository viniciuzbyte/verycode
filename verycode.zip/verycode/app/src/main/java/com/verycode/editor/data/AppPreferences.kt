package com.verycode.editor.data

import android.content.Context
import android.content.SharedPreferences

enum class AppTheme {
    SYSTEM, LIGHT, DARK
}

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("verycode_prefs", Context.MODE_PRIVATE)

    var hasCompletedOnboarding: Boolean
        get() = prefs.getBoolean(KEY_ONBOARDING_DONE, false)
        set(value) = prefs.edit().putBoolean(KEY_ONBOARDING_DONE, value).apply()

    var selectedTheme: AppTheme
        get() {
            val name = prefs.getString(KEY_THEME, AppTheme.SYSTEM.name)
            return try {
                AppTheme.valueOf(name ?: AppTheme.SYSTEM.name)
            } catch (_: Exception) {
                AppTheme.SYSTEM
            }
        }
        set(value) = prefs.edit().putString(KEY_THEME, value.name).apply()

    companion object {
        private const val KEY_ONBOARDING_DONE = "key_onboarding_done"
        private const val KEY_THEME = "key_selected_theme"
    }
}
