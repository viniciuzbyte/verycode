package com.verycode.editor.ui.theme

import androidx.compose.ui.graphics.Color

// Accent
val CodeEmerald = Color(0xFF10B981)
val CodeEmeraldLight = Color(0xFF34D399)
val CodeCyan = Color(0xFF06B6D4)

// Studio Dark (VS Code / JetBrains vibes)
val EditorDarkBg = Color(0xFF12141A)
val EditorDarkSurface = Color(0xFF1A1D24)
val EditorDarkCard = Color(0xFF222631)
val EditorDarkGutter = Color(0xFF16181F)
val EditorDarkText = Color(0xFFE2E8F0)
val EditorDarkMuted = Color(0xFF64748B)
val EditorDarkBorder = Color(0xFF2E3440)

// Studio Light (Clean & Crisp)
val EditorLightBg = Color(0xFFF1F5F9)
val EditorLightSurface = Color(0xFFFFFFFF)
val EditorLightCard = Color(0xFFF8FAFC)
val EditorLightGutter = Color(0xFFE2E8F0)
val EditorLightText = Color(0xFF0F172A)
val EditorLightMuted = Color(0xFF94A3B8)
val EditorLightBorder = Color(0xFFCBD5E1)
