package com.verycode.editor.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.caverock.androidsvg.SVG

@Composable
fun FileTypeIcon(name: String) {
    val context = LocalContext.current
    val ext = name.substringAfterLast('.', "").lowercase()
    val asset = when (ext) {
        "html", "htm" -> "icons/html.svg"
        "css" -> "icons/css.svg"
        "js", "mjs" -> "icons/javascript.svg"
        else -> "icons/file.svg"
    }

    val bitmap = remember(asset) {
        try {
            val svg = SVG.getFromAsset(context.assets, asset)
            svg.documentWidth = 48f
            svg.documentHeight = 48f
            val image = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            svg.renderToCanvas(Canvas(image))
            image.asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }

    if (bitmap != null) {
        Image(bitmap, contentDescription = "$ext icon", modifier = Modifier.size(26.dp))
    } else {
        Icon(Icons.Default.Language, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
    }
}
