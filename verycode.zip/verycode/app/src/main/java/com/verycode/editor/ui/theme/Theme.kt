package com.verycode.editor.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.verycode.editor.data.AppTheme

private val DarkColorScheme = darkColorScheme(
    primary = CodeEmerald,
    onPrimary = Color.Black,
    secondary = CodeCyan,
    background = EditorDarkBg,
    surface = EditorDarkSurface,
    surfaceVariant = EditorDarkCard,
    onBackground = EditorDarkText,
    onSurface = EditorDarkText,
    outline = EditorDarkBorder
)

private val LightColorScheme = lightColorScheme(
    primary = CodeEmerald,
    onPrimary = Color.White,
    secondary = CodeCyan,
    background = EditorLightBg,
    surface = EditorLightSurface,
    surfaceVariant = EditorLightCard,
    onBackground = EditorLightText,
    onSurface = EditorLightText,
    outline = EditorLightBorder
)

@Composable
fun VeryCodeTheme(
    themeSetting: AppTheme,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeSetting) {
        AppTheme.SYSTEM -> isSystemInDarkTheme()
        AppTheme.DARK -> true
        AppTheme.LIGHT -> false
    }

    MaterialTheme(
        colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme,
        content = content
    )
}
