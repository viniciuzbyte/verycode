package com.faddlan.verycode.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.faddlan.verycode.model.FileNode

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileTreeView(
    nodes: List<FileNode>,
    depth: Int = 0,
    onToggle: (FileNode) -> Unit,
    onOpenFile: (FileNode) -> Unit,
    onLongPress: (FileNode, FileNode?) -> Unit,
    parent: FileNode? = null
) {
    Column {
        for (node in nodes) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .combinedClickable(
                        onClick = {
                            if (node.isDirectory) onToggle(node) else onOpenFile(node)
                        },
                        onLongClick = { onLongPress(node, parent) }
                    )
                    .background(if (node.isDirectory) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.background)
                    .padding(start = (12 + depth * 14).dp, top = 8.dp, bottom = 8.dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (node.isDirectory) {
                        if (node.expanded) Icons.Filled.FolderOpen else Icons.Filled.Folder
                    } else Icons.Filled.Description,
                    contentDescription = null,
                    tint = if (node.isDirectory) VeryPrimary else VeryTextDim,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = node.name,
                    color = VeryText,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            if (node.isDirectory && node.expanded) {
                node.children?.let { children ->
                    FileTreeView(
                        nodes = children,
                        depth = depth + 1,
                        onToggle = onToggle,
                        onOpenFile = onOpenFile,
                        onLongPress = onLongPress,
                        parent = node
                    )
                }
            }
        }
    }
}
