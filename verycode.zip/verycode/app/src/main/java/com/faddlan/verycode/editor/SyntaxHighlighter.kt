package com.faddlan.verycode.editor

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString

// Soft, low-saturation palette — easy on the eyes for long sessions, works on
// both the dark and light VeryCode themes since each is a readable mid-tone.
object HighlightPaletteDark {
    val KEYWORD = Color(0xFFC9A6FF)
    val STRING = Color(0xFFA8D8C0)
    val COMMENT = Color(0xFF6E7681)
    val NUMBER = Color(0xFFE8B98A)
    val TAG = Color(0xFFE39AA6)
    val ATTR = Color(0xFFB8A1E8)
    val DEFAULT = Color(0xFFE3E1EC)
}

object HighlightPaletteLight {
    val KEYWORD = Color(0xFF7A4FD1)
    val STRING = Color(0xFF2E8B6F)
    val COMMENT = Color(0xFF9A9FAE)
    val NUMBER = Color(0xFFB5691F)
    val TAG = Color(0xFFC94F63)
    val ATTR = Color(0xFF6B4FBF)
    val DEFAULT = Color(0xFF2B2A33)
}

private var activePalette = HighlightPaletteDark

fun setHighlightDarkMode(isDark: Boolean) {
    activePalette = if (isDark) HighlightPaletteDark else HighlightPaletteLight
}

private val COLOR_KEYWORD get() = activePalette.KEYWORD
private val COLOR_STRING get() = activePalette.STRING
private val COLOR_COMMENT get() = activePalette.COMMENT
private val COLOR_NUMBER get() = activePalette.NUMBER
private val COLOR_TAG get() = activePalette.TAG
private val COLOR_ATTR get() = activePalette.ATTR
private val COLOR_DEFAULT get() = activePalette.DEFAULT

private val KEYWORDS_C_LIKE = setOf(
    "function", "const", "let", "var", "return", "if", "else", "for", "while", "do",
    "switch", "case", "break", "continue", "class", "extends", "implements", "new",
    "import", "export", "default", "from", "async", "await", "try", "catch", "finally",
    "throw", "typeof", "instanceof", "null", "undefined", "true", "false", "this",
    "def", "elif", "pass", "lambda", "yield", "with", "as", "is", "not", "and", "or",
    "fun", "val", "when", "is", "object", "companion", "override", "private", "public",
    "protected", "internal", "suspend", "package", "interface", "data", "sealed",
    "public", "static", "void", "int", "float", "double", "boolean", "String", "final"
)

private val tokenRegex = Regex(
    """(//.*|#.*)|("""" + """(?:[^"\\]|\\.)*"""" + """|'(?:[^'\\]|\\.)*')|(\b\d+(\.\d+)?\b)|(<\/?[a-zA-Z][a-zA-Z0-9]*)|([a-zA-Z_][a-zA-Z0-9_]*)"""
)

/**
 * Line-oriented single-pass tokenizer. Not a full grammar — good enough for readable
 * highlighting across the languages this editor targets without pulling in a parser dep.
 */
fun highlight(code: String, language: String): AnnotatedString = buildAnnotatedString {
    append(code)
    val isMarkup = language == "html" || language == "xml"

    var idx = 0
    for (match in tokenRegex.findAll(code)) {
        val range = match.range
        if (range.first < idx) continue

        val comment = match.groups[1]
        val string = match.groups[2]
        val number = match.groups[3]
        val tagOpen = match.groups[5]
        val word = match.groups[6]

        when {
            comment != null -> addStyle(SpanStyle(color = COLOR_COMMENT), range.first, range.last + 1)
            string != null -> addStyle(SpanStyle(color = COLOR_STRING), range.first, range.last + 1)
            number != null -> addStyle(SpanStyle(color = COLOR_NUMBER), range.first, range.last + 1)
            tagOpen != null && isMarkup -> addStyle(SpanStyle(color = COLOR_TAG), range.first, range.last + 1)
            word != null -> {
                if (word.value in KEYWORDS_C_LIKE) {
                    addStyle(SpanStyle(color = COLOR_KEYWORD), range.first, range.last + 1)
                } else if (isMarkup) {
                    addStyle(SpanStyle(color = COLOR_ATTR), range.first, range.last + 1)
                }
            }
        }
        idx = range.last + 1
    }
}

val defaultTextColor: Color get() = COLOR_DEFAULT
