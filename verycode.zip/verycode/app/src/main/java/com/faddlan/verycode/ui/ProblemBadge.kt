package com.faddlan.verycode.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class ProblemEntry(val fileName: String, val line: Int, val message: String, val severity: Severity)
enum class Severity { ERROR, WARNING }

/**
 * Vertical ribbon tab pinned to the right edge, matching Acode's "Masalah" (Problems) tab:
 * a narrow colored strip with the label rotated 90° reading bottom-to-top.
 */
@Composable
fun ProblemBadge(
    problemCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (problemCount == 0) return
    Box(
        modifier = modifier
            .width(28.dp)
            .wrapContentHeight()
            .clip(RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp))
            .background(VeryError)
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "Masalah ($problemCount)",
            color = Color.White,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            maxLines = 1,
            modifier = Modifier.rotate(-90f)
        )
    }
}
