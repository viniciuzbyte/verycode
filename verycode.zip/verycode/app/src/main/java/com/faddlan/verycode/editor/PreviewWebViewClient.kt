package com.faddlan.verycode.editor

import android.content.Context
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.faddlan.verycode.fs.SafFileRepository
import java.io.ByteArrayInputStream

/**
 * Intercepts relative-path requests the WebView makes while rendering the HTML string
 * we injected (loadDataWithBaseURL uses a fake https base so relative src/href resolve
 * here instead of hitting the real network), and serves them from the SAF tree so
 * local <link>/<script>/<img> references next to the HTML file actually resolve.
 */
class PreviewWebViewClient(
    private val context: Context,
    private val repo: SafFileRepository,
    private val htmlParentUri: Uri
) : WebViewClient() {

    override fun shouldInterceptRequest(
        view: WebView,
        request: WebResourceRequest
    ): WebResourceResponse? {
        val url = request.url
        if (url.scheme == "http" || url.scheme == "https") {
            if (url.host != PREVIEW_FAKE_HOST) return null // let real network requests (CDNs) through
        }

        val relativePath = url.path?.removePrefix("/") ?: return null
        if (relativePath.isBlank()) return null

        return try {
            val sibling = repo.findSibling(htmlParentUri, Uri.decode(relativePath)) ?: return null
            val bytes = context.contentResolver.openInputStream(sibling)?.readBytes() ?: return null
            WebResourceResponse(
                mimeTypeFor(relativePath),
                "utf-8",
                ByteArrayInputStream(bytes)
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun mimeTypeFor(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "css" -> "text/css"
        "js", "mjs" -> "application/javascript"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "svg" -> "image/svg+xml"
        "json" -> "application/json"
        "woff2" -> "font/woff2"
        "woff" -> "font/woff"
        else -> "application/octet-stream"
    }

    companion object {
        const val PREVIEW_FAKE_HOST = "verycode.preview"
        const val PREVIEW_BASE_URL = "https://$PREVIEW_FAKE_HOST/"
    }
}
