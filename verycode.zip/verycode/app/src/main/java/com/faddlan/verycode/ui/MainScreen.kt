package com.faddlan.verycode.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.width
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.faddlan.verycode.fs.SafFileRepository
import com.faddlan.verycode.model.FileNode
import com.faddlan.verycode.model.guessLanguage
import com.faddlan.verycode.model.isPreviewable
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainScreen(
    vm: AppViewModel,
    repo: SafFileRepository,
    onRequestFolder: () -> Unit
) {
    val context = LocalContext.current
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHost = remember { SnackbarHostState() }

    var pendingCreateParent by remember { mutableStateOf<FileNode?>(null) }
    var pendingCreateIsDir by remember { mutableStateOf(false) }

    LaunchedEffect(vm.lastEvent) {
        when (val event = vm.lastEvent) {
            is UiEvent.Error -> snackbarHost.showSnackbar(event.message)
            is UiEvent.Info -> snackbarHost.showSnackbar(event.message)
            null -> {}
        }
        vm.consumeEvent()
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = VerySurface) {
                Column(modifier = Modifier.fillMaxSize().width(280.dp)) {
                    Text(
                        text = "Proyek",
                        color = VeryTextDim,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(VerySurface)
                            .padding(16.dp)
                    )
                    Box(modifier = Modifier.fillMaxSize()) {
                        FileTreeView(
                            nodes = vm.roots,
                            onToggle = { vm.toggleExpand(it) },
                            onOpenFile = {
                                vm.openFile(it)
                                scope.launch { drawerState.close() }
                            },
                            onLongPress = { node, parent ->
                                if (node.isDirectory) {
                                    pendingCreateParent = node
                                }
                            }
                        )
                    }
                }
            }
        }
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHost) },
            containerColor = VeryBg
        ) { padding ->
            Row(modifier = Modifier.fillMaxSize().background(VeryBg).padding(padding)) {
                Column(modifier = Modifier.weight(1f).fillMaxSize()) {
                    VeryCodeTopBar(
                        onMenu = { scope.launch { drawerState.open() } },
                        onAddFolder = onRequestFolder,
                        onPreview = { vm.showPreview() },
                        previewEnabled = vm.activeTab?.let { isPreviewable(it.name) } ?: false
                    )

                    if (vm.tabs.isNotEmpty()) {
                        TabBar(
                            tabs = vm.tabs,
                            activeIndex = vm.activeTabIndex,
                            onSelect = { vm.selectTab(it) },
                            onClose = { vm.closeTab(it) }
                        )
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        if (vm.previewVisible && vm.previewHtml != null && vm.previewParentUri != null) {
                            PreviewPanel(
                                html = vm.previewHtml!!,
                                htmlParentUri = vm.activeTab?.uri ?: vm.previewParentUri!!,
                                repo = repo,
                                onOpenExternal = {
                                    openHtmlExternally(context, repo, vm.activeTab?.uri)
                                },
                                onClose = { vm.hidePreview() }
                            )
                        } else {
                            val tab = vm.activeTab
                            if (tab == null) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text("Buka folder lalu pilih file untuk mulai mengedit", color = VeryTextDim)
                                }
                            } else {
                                CodeEditorField(
                                    value = tab.content,
                                    language = guessLanguage(tab.name),
                                    onValueChange = { vm.updateActiveContent(it) },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }

                    if (!vm.previewVisible) {
                        EditorToolbar(
                            canUndo = false,
                            canRedo = false,
                            isDirty = vm.activeTab?.isDirty ?: false,
                            onCtrl = {},
                            onTab = { vm.activeTab?.let { vm.updateActiveContent(it.content + "\t") } },
                            onShift = {},
                            onUndo = {},
                            onRedo = {},
                            onSearch = {},
                            onSave = { vm.saveActiveTab() },
                            onEsc = {}
                        )
                    }
                }
            }
        }
    }

    pendingCreateParent?.let { parent ->
        CreateEntryDialog(
            title = "Buat item baru di ${parent.name}",
            onDismiss = { pendingCreateParent = null },
            onConfirm = { name ->
                if (name.contains('.')) {
                    vm.createFile(parent, name) {}
                } else {
                    vm.createDirectory(parent, name)
                }
                pendingCreateParent = null
            }
        )
    }
}

/**
 * Exports the current tab's content to the app's external cache dir (shareable via
 * FileProvider) and launches ACTION_VIEW so a real browser renders it — this is the
 * "open to website preview maximally" external path, separate from the in-app WebView.
 */
private fun openHtmlExternally(context: android.content.Context, repo: SafFileRepository, uri: Uri?) {
    if (uri == null) return
    try {
        val content = repo.readText(uri)
        val cacheFile = java.io.File(context.cacheDir, "preview_external.html")
        cacheFile.writeText(content)
        val contentUri = androidx.core.content.FileProvider.getUriForFile(
            context, "com.faddlan.verycode.fileprovider", cacheFile
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(contentUri, "text/html")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (_: Exception) {
        // Swallowed intentionally at UI edge; vm.lastEvent path not reachable from this
        // static helper — a failed external open simply does nothing visible beyond
        // the user noticing no browser opened, which is an acceptable degrade here.
    }
}
