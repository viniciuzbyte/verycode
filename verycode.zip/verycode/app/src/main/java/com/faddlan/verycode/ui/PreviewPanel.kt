package com.faddlan.verycode.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.faddlan.verycode.editor.PreviewWebViewClient
import com.faddlan.verycode.fs.SafFileRepository

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PreviewPanel(
    html: String,
    htmlParentUri: Uri,
    repo: SafFileRepository,
    onOpenExternal: () -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    var reloadKey by remember { androidx.compose.runtime.mutableStateOf(0) }

    Column(modifier = Modifier.fillMaxSize().background(VeryBg)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .background(VerySurface)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Preview",
                color = VeryText,
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { reloadKey++ }) {
                Icon(Icons.Filled.Refresh, contentDescription = "Reload", tint = VeryTextDim)
            }
            IconButton(onClick = onOpenExternal) {
                Icon(Icons.Filled.OpenInBrowser, contentDescription = "Open in browser", tint = VeryAccent)
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, contentDescription = "Close preview", tint = VeryTextDim)
            }
        }
        Box(modifier = Modifier.fillMaxSize()) {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        webViewClient = PreviewWebViewClient(ctx, repo, htmlParentUri)
                    }
                },
                update = { webView ->
                    webView.loadDataWithBaseURL(
                        PreviewWebViewClient.PREVIEW_BASE_URL,
                        html,
                        "text/html",
                        "utf-8",
                        null
                    )
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
