package com.faddlan.verycode.fs

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import com.faddlan.verycode.model.FileNode
import java.io.IOException

/**
 * Wraps the Storage Access Framework so the rest of the app only deals with
 * FileNode/Uri, never raw java.io.File. This is what grants "external file
 * permission": the user picks a tree via ACTION_OPEN_DOCUMENT_TREE, we persist
 * the permission, and every read/write goes through DocumentFile against that
 * granted Uri.
 */
class SafFileRepository(private val context: Context) {

    private val resolver: ContentResolver get() = context.contentResolver

    fun persistTreePermission(treeUri: Uri) {
        val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
            android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        resolver.takePersistableUriPermission(treeUri, flags)
    }

    fun listPersistedRoots(): List<Uri> =
        resolver.persistedUriPermissions
            .filter { it.isReadPermission }
            .map { it.uri }

    fun releaseTreePermission(treeUri: Uri) {
        val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
            android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        resolver.releasePersistableUriPermission(treeUri, flags)
    }

    fun rootNode(treeUri: Uri): FileNode? {
        val doc = DocumentFile.fromTreeUri(context, treeUri) ?: return null
        if (!doc.exists()) return null
        return FileNode(
            uri = doc.uri,
            name = doc.name ?: "root",
            isDirectory = true,
            parentUri = null
        )
    }

    /** Lists direct children of a directory node, sorted: directories first, then alphabetical. */
    fun listChildren(node: FileNode): List<FileNode> {
        val dir = DocumentFile.fromTreeUri(context, node.uri)
            ?: DocumentFile.fromSingleUri(context, node.uri)
            ?: return emptyList()
        val childDir = if (node.parentUri == null) {
            // node is itself a tree root; children live under the tree document id
            DocumentFile.fromTreeUri(context, node.uri)
        } else {
            resolveAsDirectory(node.uri)
        } ?: dir

        val children = childDir.listFiles().mapNotNull { child ->
            val name = child.name ?: return@mapNotNull null
            FileNode(
                uri = child.uri,
                name = name,
                isDirectory = child.isDirectory,
                parentUri = node.uri
            )
        }
        return children.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    }

    private fun resolveAsDirectory(uri: Uri): DocumentFile? {
        return DocumentFile.fromTreeUri(context, uri) ?: run {
            val docId = try {
                DocumentsContract.getDocumentId(uri)
            } catch (_: Exception) {
                return null
            }
            val treeId = try {
                DocumentsContract.getTreeDocumentId(uri)
            } catch (_: Exception) {
                docId
            }
            val childUri = DocumentsContract.buildDocumentUriUsingTree(uri, docId)
            DocumentFile.fromSingleUri(context, childUri)
        }
    }

    @Throws(IOException::class)
    fun readText(uri: Uri): String {
        resolver.openInputStream(uri)?.use { stream ->
            return stream.readBytes().toString(Charsets.UTF_8)
        } ?: throw IOException("Cannot open input stream for $uri")
    }

    @Throws(IOException::class)
    fun writeText(uri: Uri, content: String) {
        resolver.openOutputStream(uri, "wt")?.use { stream ->
            stream.write(content.toByteArray(Charsets.UTF_8))
        } ?: throw IOException("Cannot open output stream for $uri")
    }

    @Throws(IOException::class)
    fun createFile(parentUri: Uri, name: String, mimeType: String = "text/plain"): Uri {
        val parent = resolveAsDirectory(parentUri)
            ?: DocumentFile.fromTreeUri(context, parentUri)
            ?: throw IOException("Parent is not a directory")
        val existing = parent.findFile(name)
        if (existing != null) return existing.uri
        val created = parent.createFile(mimeType, name)
            ?: throw IOException("Failed to create file $name")
        return created.uri
    }

    @Throws(IOException::class)
    fun createDirectory(parentUri: Uri, name: String): Uri {
        val parent = resolveAsDirectory(parentUri)
            ?: DocumentFile.fromTreeUri(context, parentUri)
            ?: throw IOException("Parent is not a directory")
        val existing = parent.findFile(name)
        if (existing != null && existing.isDirectory) return existing.uri
        val created = parent.createDirectory(name)
            ?: throw IOException("Failed to create directory $name")
        return created.uri
    }

    @Throws(IOException::class)
    fun delete(uri: Uri): Boolean {
        val doc = resolveAsDirectory(uri) ?: DocumentFile.fromSingleUri(context, uri)
        return doc?.delete() ?: false
    }

    @Throws(IOException::class)
    fun rename(uri: Uri, newName: String): Uri {
        val doc = resolveAsDirectory(uri) ?: DocumentFile.fromSingleUri(context, uri)
            ?: throw IOException("Target not found")
        return DocumentsContract.renameDocument(resolver, uri, newName) ?: doc.uri
    }

    /**
     * Resolves sibling file URIs within the same directory for HTML preview asset loading
     * (relative <link>/<script> src resolution happens in PreviewWebViewClient via DocumentsContract,
     * not here — this just exposes the parent lookup it needs).
     */
    fun findSibling(parentUri: Uri, relativeName: String): Uri? {
        val parent = resolveAsDirectory(parentUri) ?: return null
        val segments = relativeName.split("/").filter { it.isNotBlank() && it != "." }
        var current: DocumentFile = parent
        for ((index, segment) in segments.withIndex()) {
            if (segment == "..") {
                current = current.parentFile ?: return null
                continue
            }
            val found = current.findFile(segment) ?: return null
            if (index == segments.lastIndex) return found.uri
            current = found
        }
        return null
    }
}
