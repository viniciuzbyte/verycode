package com.faddlan.verycode.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.faddlan.verycode.model.OpenTab

@Composable
fun TabBar(
    tabs: List<OpenTab>,
    activeIndex: Int,
    onSelect: (Int) -> Unit,
    onClose: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(42.dp)
            .background(VerySurface)
            .horizontalScroll(rememberScrollState())
    ) {
        tabs.forEachIndexed { index, tab ->
            val selected = index == activeIndex
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .background(if (selected) VerySurfaceAlt else VerySurface)
                    .clickable { onSelect(index) }
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tab.name,
                    color = if (selected) VeryText else VeryTextDim,
                    style = MaterialTheme.typography.labelLarge
                )
                Box(modifier = Modifier.size(18.dp).padding(start = 6.dp)) {
                    if (tab.isDirty) {
                        Icon(
                            imageVector = Icons.Filled.Circle,
                            contentDescription = "unsaved",
                            tint = VeryAccent,
                            modifier = Modifier.size(8.dp).align(Alignment.Center)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "close",
                            tint = VeryTextDim,
                            modifier = Modifier
                                .size(14.dp)
                                .clickable { onClose(index) }
                                .align(Alignment.Center)
                        )
                    }
                }
            }
        }
    }
}
