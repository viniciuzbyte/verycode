package com.faddlan.verycode

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.faddlan.verycode.fs.SafFileRepository
import com.faddlan.verycode.ui.AppViewModel
import com.faddlan.verycode.ui.AppViewModelFactory
import com.faddlan.verycode.ui.MainScreen
import com.faddlan.verycode.ui.VeryCodeTheme

class MainActivity : ComponentActivity() {

    private lateinit var repo: SafFileRepository

    private val vm: AppViewModel by viewModels {
        AppViewModelFactory(applicationContext)
    }

    // ACTION_OPEN_DOCUMENT_TREE is the one-time grant: the user picks a folder once,
    // we call persistTreePermission (takePersistableUriPermission) so the grant survives
    // app restarts and device reboots — loadRootsFromPermissions() on every launch means
    // we never have to ask again for a folder already granted.
    private val openTreeLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri: Uri? = result.data?.data
        if (result.resultCode == RESULT_OK && uri != null) {
            vm.addRoot(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = SafFileRepository(applicationContext)
        vm.loadRootsFromPermissions()

        setContent {
            VeryCodeTheme {
                MainScreen(
                    vm = vm,
                    repo = repo,
                    onRequestFolder = { launchFolderPicker() }
                )
            }
        }
    }

    private fun launchFolderPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
            )
        }
        openTreeLauncher.launch(intent)
    }
}
