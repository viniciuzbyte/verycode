package com.faddlan.verycode.model

import android.net.Uri

data class FileNode(
    val uri: Uri,
    val name: String,
    val isDirectory: Boolean,
    val parentUri: Uri?,
    var children: List<FileNode>? = null,
    var expanded: Boolean = false
)

data class OpenTab(
    val uri: Uri,
    val name: String,
    var content: String,
    var isDirty: Boolean = false
)

fun guessLanguage(fileName: String): String {
    val ext = fileName.substringAfterLast('.', "").lowercase()
    return when (ext) {
        "html", "htm" -> "html"
        "css" -> "css"
        "js", "mjs", "cjs" -> "javascript"
        "ts", "tsx" -> "typescript"
        "json" -> "json"
        "py" -> "python"
        "kt", "kts" -> "kotlin"
        "java" -> "java"
        "xml" -> "xml"
        "md" -> "markdown"
        "c", "h" -> "c"
        "cpp", "hpp", "cc" -> "cpp"
        "sh" -> "shell"
        "yml", "yaml" -> "yaml"
        else -> "plain"
    }
}

fun isPreviewable(fileName: String): Boolean {
    val ext = fileName.substringAfterLast('.', "").lowercase()
    return ext == "html" || ext == "htm"
}
