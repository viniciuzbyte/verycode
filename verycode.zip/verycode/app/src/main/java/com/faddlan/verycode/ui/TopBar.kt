package com.faddlan.verycode.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun VeryCodeTopBar(
    onMenu: () -> Unit,
    onAddFolder: () -> Unit,
    onPreview: () -> Unit,
    previewEnabled: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .background(VerySurface)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onMenu) {
            Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = VeryText)
        }
        Text(
            text = "VeryCode",
            color = VeryPrimary,
            style = androidx.compose.material3.MaterialTheme.typography.titleMedium,
            modifier = Modifier.weight(1f)
        )
        if (previewEnabled) {
            IconButton(onClick = onPreview) {
                Icon(Icons.Filled.Visibility, contentDescription = "Preview", tint = VeryAccent)
            }
        }
        IconButton(onClick = onAddFolder) {
            Icon(Icons.Filled.CreateNewFolder, contentDescription = "Tambah folder", tint = VeryText)
        }
    }
}
