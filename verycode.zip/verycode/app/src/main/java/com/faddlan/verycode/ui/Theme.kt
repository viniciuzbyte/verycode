package com.faddlan.verycode.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import com.faddlan.verycode.editor.setHighlightDarkMode

// ---- Dark palette (default) ----
val VeryBgDark = Color(0xFF13111C)
val VerySurfaceDark = Color(0xFF1C1A28)
val VerySurfaceAltDark = Color(0xFF241F38)
val VeryPrimaryDark = Color(0xFF9D7BFF)
val VeryAccentDark = Color(0xFF5CE8C5)
val VeryTextDark = Color(0xFFECE9F7)
val VeryTextDimDark = Color(0xFF8D86A8)
val VeryErrorDark = Color(0xFFFF6B81)

// ---- Light palette ----
val VeryBgLight = Color(0xFFFAF9FD)
val VerySurfaceLight = Color(0xFFFFFFFF)
val VerySurfaceAltLight = Color(0xFFF1EEFA)
val VeryPrimaryLight = Color(0xFF7A4FD1)
val VeryAccentLight = Color(0xFF2E8B6F)
val VeryTextLight = Color(0xFF211F2B)
val VeryTextDimLight = Color(0xFF6E6B80)
val VeryErrorLight = Color(0xFFD1435B)

// Mutable "current" references so plain composables (FileTree, TabBar, etc.)
// that reference VeryBg/VeryText/... directly stay in sync with the active theme
// without threading a scheme parameter through every leaf composable.
var VeryBg = VeryBgDark
    private set
var VerySurface = VerySurfaceDark
    private set
var VerySurfaceAlt = VerySurfaceAltDark
    private set
var VeryPrimary = VeryPrimaryDark
    private set
var VeryAccent = VeryAccentDark
    private set
var VeryText = VeryTextDark
    private set
var VeryTextDim = VeryTextDimDark
    private set
var VeryError = VeryErrorDark
    private set

private fun applyPalette(dark: Boolean) {
    if (dark) {
        VeryBg = VeryBgDark; VerySurface = VerySurfaceDark; VerySurfaceAlt = VerySurfaceAltDark
        VeryPrimary = VeryPrimaryDark; VeryAccent = VeryAccentDark
        VeryText = VeryTextDark; VeryTextDim = VeryTextDimDark; VeryError = VeryErrorDark
    } else {
        VeryBg = VeryBgLight; VerySurface = VerySurfaceLight; VerySurfaceAlt = VerySurfaceAltLight
        VeryPrimary = VeryPrimaryLight; VeryAccent = VeryAccentLight
        VeryText = VeryTextLight; VeryTextDim = VeryTextDimLight; VeryError = VeryErrorLight
    }
    setHighlightDarkMode(dark)
}

private val VeryDarkScheme = darkColorScheme(
    primary = VeryPrimaryDark,
    onPrimary = Color(0xFF1A1230),
    secondary = VeryAccentDark,
    onSecondary = Color(0xFF0B2420),
    background = VeryBgDark,
    onBackground = VeryTextDark,
    surface = VerySurfaceDark,
    onSurface = VeryTextDark,
    surfaceVariant = VerySurfaceAltDark,
    onSurfaceVariant = VeryTextDimDark,
    error = VeryErrorDark
)

private val VeryLightScheme = lightColorScheme(
    primary = VeryPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    secondary = VeryAccentLight,
    onSecondary = Color(0xFFFFFFFF),
    background = VeryBgLight,
    onBackground = VeryTextLight,
    surface = VerySurfaceLight,
    onSurface = VeryTextLight,
    surfaceVariant = VerySurfaceAltLight,
    onSurfaceVariant = VeryTextDimLight,
    error = VeryErrorLight
)

/** Follows the device's system dark/light setting automatically, Acode-style. */
@Composable
fun VeryCodeTheme(content: @Composable () -> Unit) {
    val isDark = isSystemInDarkTheme()
    SideEffect { applyPalette(isDark) }
    MaterialTheme(
        colorScheme = if (isDark) VeryDarkScheme else VeryLightScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
