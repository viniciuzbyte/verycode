package com.faddlan.verycode.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TransformedText
import androidx.compose.ui.text.VisualTransformation
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.faddlan.verycode.editor.highlight

private val identityOffsetMapping = object : OffsetMapping {
    override fun originalToTransformed(offset: Int) = offset
    override fun transformedToOriginal(offset: Int) = offset
}

class HighlightTransformation(private val language: String) : VisualTransformation {
    override fun filter(text: androidx.compose.ui.text.AnnotatedString): TransformedText {
        val highlighted = highlight(text.text, language)
        return TransformedText(highlighted, identityOffsetMapping)
    }
}

@Composable
fun CodeEditorField(
    value: String,
    language: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var fieldValue by remember(value) {
        androidx.compose.runtime.mutableStateOf(
            TextFieldValue(value, selection = TextRange(value.length.coerceAtMost(value.length)))
        )
    }
    val lineCount = remember(fieldValue.text) { fieldValue.text.count { it == '\n' } + 1 }
    val horizontalScroll = rememberScrollState()

    Row(modifier = modifier.fillMaxSize()) {
        Text(
            text = (1..lineCount).joinToString("\n") { it.toString() },
            color = VeryTextDim,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
            fontSize = 13.sp,
            lineHeight = 19.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.End,
            overflow = TextOverflow.Visible,
            modifier = Modifier
                .width(40.dp)
                .padding(top = 12.dp, end = 6.dp)
        )
        BasicTextField(
            value = fieldValue,
            onValueChange = {
                fieldValue = it
                onValueChange(it.text)
            },
            visualTransformation = HighlightTransformation(language),
            textStyle = androidx.compose.ui.text.TextStyle(
                color = defaultTextColorCompat(),
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                fontSize = 13.sp,
                lineHeight = 19.sp
            ),
            cursorBrush = androidx.compose.ui.graphics.SolidColor(VeryPrimary),
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .horizontalScroll(horizontalScroll)
                .padding(top = 12.dp, bottom = 24.dp, end = 16.dp)
        )
    }
}

private fun defaultTextColorCompat() = com.faddlan.verycode.editor.defaultTextColor
