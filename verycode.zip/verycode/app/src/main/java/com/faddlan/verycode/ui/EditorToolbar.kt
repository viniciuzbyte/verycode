package com.faddlan.verycode.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardTab
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Mirrors Acode's bottom accessory row: literal key chips on the left (CTRL/TAB/SHFT,
 * which insert their control sequence into the editor at the cursor) and action icons
 * on the right (undo/redo/search/save/ESC which dismisses the keyboard).
 */
@Composable
fun EditorToolbar(
    canUndo: Boolean,
    canRedo: Boolean,
    isDirty: Boolean,
    onCtrl: () -> Unit,
    onTab: () -> Unit,
    onShift: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onSearch: () -> Unit,
    onSave: () -> Unit,
    onEsc: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .background(VerySurface),
        verticalAlignment = Alignment.CenterVertically
    ) {
        KeyChip(label = "CTRL", onClick = onCtrl)
        IconChip(icon = Icons.AutoMirrored.Filled.KeyboardTab, contentDescription = "Tab", onClick = onTab)
        KeyChip(label = "SHFT", onClick = onShift)

        Box(modifier = Modifier.width(1.dp).height(22.dp).background(VeryTextDim.copy(alpha = 0.25f)))

        IconChip(
            icon = Icons.AutoMirrored.Filled.Undo,
            contentDescription = "Undo",
            onClick = onUndo,
            tint = if (canUndo) VeryText else VeryTextDim.copy(alpha = 0.4f)
        )
        IconChip(
            icon = Icons.AutoMirrored.Filled.Redo,
            contentDescription = "Redo",
            onClick = onRedo,
            tint = if (canRedo) VeryText else VeryTextDim.copy(alpha = 0.4f)
        )
        IconChip(icon = Icons.Filled.Search, contentDescription = "Cari", onClick = onSearch)
        IconChip(
            icon = Icons.Filled.Save,
            contentDescription = "Simpan",
            onClick = onSave,
            tint = if (isDirty) VeryAccent else VeryTextDim
        )

        Box(modifier = Modifier.weight(1f))

        KeyChip(label = "ESC", onClick = onEsc)
    }
}

@Composable
private fun KeyChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .padding(horizontal = 4.dp)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            color = VeryText,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun IconChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    tint: androidx.compose.ui.graphics.Color = VeryText
) {
    Box(
        modifier = Modifier
            .padding(horizontal = 2.dp)
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        Icon(icon, contentDescription = contentDescription, tint = tint, modifier = Modifier.width(20.dp))
    }
}
