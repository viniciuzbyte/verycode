package com.faddlan.verycode.ui

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.faddlan.verycode.fs.SafFileRepository
import com.faddlan.verycode.model.FileNode
import com.faddlan.verycode.model.OpenTab
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class UiEvent {
    data class Error(val message: String) : UiEvent()
    data class Info(val message: String) : UiEvent()
}

class AppViewModel(private val repo: SafFileRepository) : ViewModel() {

    var roots = mutableStateListOf<FileNode>()
        private set

    var tabs = mutableStateListOf<OpenTab>()
        private set

    var activeTabIndex by mutableStateOf(-1)
        private set

    var previewVisible by mutableStateOf(false)
        private set

    var previewHtml by mutableStateOf<String?>(null)
        private set

    var previewParentUri by mutableStateOf<Uri?>(null)
        private set

    var lastEvent by mutableStateOf<UiEvent?>(null)
        private set

    val activeTab: OpenTab?
        get() = tabs.getOrNull(activeTabIndex)

    fun consumeEvent() {
        lastEvent = null
    }

    fun addRoot(treeUri: Uri) {
        repo.persistTreePermission(treeUri)
        val node = repo.rootNode(treeUri) ?: run {
            lastEvent = UiEvent.Error("Tidak bisa membuka folder itu.")
            return
        }
        if (roots.none { it.uri == node.uri }) {
            roots.add(node)
        }
    }

    fun loadRootsFromPermissions() {
        roots.clear()
        for (uri in repo.listPersistedRoots()) {
            repo.rootNode(uri)?.let { roots.add(it) }
        }
    }

    fun toggleExpand(node: FileNode) {
        val idx = indexOfNode(node.uri) ?: return
        node.expanded = !node.expanded
        if (node.expanded && node.children == null) {
            viewModelScope.launch {
                val children = withContext(Dispatchers.IO) { repo.listChildren(node) }
                node.children = children
                roots[idx] = roots[idx] // trigger recomposition of root list reference
            }
        }
    }

    private fun indexOfNode(uri: Uri): Int? {
        val i = roots.indexOfFirst { it.uri == uri }
        return if (i >= 0) i else null
    }

    fun refreshChildren(node: FileNode, onDone: (List<FileNode>) -> Unit) {
        viewModelScope.launch {
            val children = withContext(Dispatchers.IO) { repo.listChildren(node) }
            node.children = children
            onDone(children)
        }
    }

    fun openFile(node: FileNode) {
        val existing = tabs.indexOfFirst { it.uri == node.uri }
        if (existing >= 0) {
            activeTabIndex = existing
            return
        }
        viewModelScope.launch {
            val content = try {
                withContext(Dispatchers.IO) { repo.readText(node.uri) }
            } catch (e: Exception) {
                lastEvent = UiEvent.Error("Gagal membaca ${node.name}: ${e.message}")
                return@launch
            }
            tabs.add(OpenTab(uri = node.uri, name = node.name, content = content))
            activeTabIndex = tabs.lastIndex
        }
    }

    fun selectTab(index: Int) {
        activeTabIndex = index
    }

    fun closeTab(index: Int) {
        if (index < 0 || index >= tabs.size) return
        tabs.removeAt(index)
        activeTabIndex = when {
            tabs.isEmpty() -> -1
            index <= activeTabIndex -> (activeTabIndex - 1).coerceAtLeast(0)
            else -> activeTabIndex
        }
    }

    fun updateActiveContent(newContent: String) {
        val tab = activeTab ?: return
        tab.content = newContent
        tab.isDirty = true
    }

    fun saveActiveTab() {
        val tab = activeTab ?: return
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { repo.writeText(tab.uri, tab.content) }
                tab.isDirty = false
                lastEvent = UiEvent.Info("Tersimpan: ${tab.name}")
            } catch (e: Exception) {
                lastEvent = UiEvent.Error("Gagal menyimpan: ${e.message}")
            }
        }
    }

    fun createFile(parent: FileNode, name: String, onCreated: (FileNode) -> Unit) {
        viewModelScope.launch {
            try {
                val uri = withContext(Dispatchers.IO) { repo.createFile(parent.uri, name) }
                refreshChildren(parent) {}
                onCreated(FileNode(uri, name, false, parent.uri))
            } catch (e: Exception) {
                lastEvent = UiEvent.Error("Gagal membuat file: ${e.message}")
            }
        }
    }

    fun createDirectory(parent: FileNode, name: String) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { repo.createDirectory(parent.uri, name) }
                refreshChildren(parent) {}
            } catch (e: Exception) {
                lastEvent = UiEvent.Error("Gagal membuat folder: ${e.message}")
            }
        }
    }

    fun deleteNode(node: FileNode, parent: FileNode?) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { repo.delete(node.uri) }
                val closingIdx = tabs.indexOfFirst { it.uri == node.uri }
                if (closingIdx >= 0) closeTab(closingIdx)
                parent?.let { refreshChildren(it) {} }
            } catch (e: Exception) {
                lastEvent = UiEvent.Error("Gagal menghapus: ${e.message}")
            }
        }
    }

    fun showPreview() {
        val tab = activeTab ?: return
        previewHtml = tab.content
        previewParentUri = tab.uri // caller derives parent dir from this
        previewVisible = true
    }

    fun hidePreview() {
        previewVisible = false
    }
}
