# VeryCode

A lightweight code editor for Android — Acode-inspired workflow, distinct violet/slate visual
identity, dark/light theme following the system, SAF-based external folder access, and live HTML
preview (in-app WebView + "Open in Browser" for full-fidelity rendering).

## Features

- **File tree** over any folder the user grants via `ACTION_OPEN_DOCUMENT_TREE` (Storage Access
  Framework). The grant is requested once; `takePersistableUriPermission` makes it survive app
  restarts, so the user is never asked twice for the same folder.
- Files created inside a granted folder are real documents written through that folder's SAF tree —
  they appear immediately in ZArchiver, MT Manager, or any other file manager pointed at the same
  location, because nothing is written to app-private storage.
- **Tabs**, dirty-state indicator, soft-palette syntax highlighting (HTML/CSS/JS/TS/JSON/Python/
  Kotlin/Java/XML/Markdown/C/C++/Shell/YAML), line numbers.
- **Acode-style bottom toolbar**: CTRL / Tab / Shift key chips, undo/redo, search, save, ESC.
- **HTML preview**: in-app WebView that resolves relative `<link>`/`<script>`/`<img>` paths back
  through the same SAF folder, plus a one-tap "Open in Browser" that exports to a `FileProvider`
  URI for full external rendering.
- Dark and light color schemes, selected automatically from the device's system setting.

## Project layout

```
app/src/main/java/com/faddlan/verycode/
  MainActivity.kt          – SAF folder picker, permission persistence, Compose host
  model/FileNode.kt         – tree node + open-tab models, language/preview detection
  fs/SafFileRepository.kt   – all SAF document operations (list/read/write/create/delete)
  editor/SyntaxHighlighter.kt     – regex tokenizer -> AnnotatedString, dark/light palettes
  editor/PreviewWebViewClient.kt  – resolves relative asset paths through SAF for preview
  ui/                        – Compose screens: file tree, tabs, editor field, toolbar,
                                preview panel, theme
```

## Build

Requires JDK 17.

```sh
gradle wrapper --gradle-version 8.7   # one-time, generates gradlew
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## CI

`.github/workflows/build.yml` builds debug + unsigned release APKs on every push to `main` and on
pull requests, uploads them as workflow artifacts, and attaches them to a GitHub Release when a
`v*` tag is pushed.
