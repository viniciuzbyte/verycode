# VeryCode 1.1.0

Native Android web-code editor built with Kotlin, Jetpack Compose and Material 3.

## Included
- Jetpack Compose editor interface.
- Open files with Android Storage Access Framework.
- Select a project folder and browse its direct child files.
- Create HTML, CSS and JavaScript files in the selected folder.
- SVG file-type icons for HTML, CSS, JavaScript and generic files.
- Edit and save text files.
- In-app HTML preview using WebView.
- Open the current document with an external browser such as Chrome.
- GitHub Actions workflow for APK build.
- Very-Enckotlin Gradle task: R8 obfuscation and resource shrinking.

## Very-Enckotlin protection

Run:

```bash
gradle :app:veryEnckotlin
```

This task builds the debug APK with R8 enabled. R8 performs code shrinking, optimization and symbol obfuscation; resource shrinking is also enabled. This is not cryptographic encryption of DEX bytecode. APK code can still be reverse engineered by a sufficiently capable analyst. Keep secrets, API keys and private credentials out of the app.

The R8 mapping file is generated at:

`app/build/outputs/mapping/debug/mapping.txt`

Keep this file private and retain it for crash deobfuscation.

## Build locally

Requirements: JDK 17, Android SDK 35 and Gradle 8.9.

```bash
gradle :app:assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

Upload the project contents to a GitHub repository. Push to `main` or `master`, or run the `Build VeryCode APK` workflow manually from the Actions tab. Download the `verycode-enckotlin-apk` artifact.

## Storage permissions

The app uses Android Storage Access Framework. Users explicitly choose files and folders, and Android grants access to the selected locations. VeryCode does not request unrestricted `MANAGE_EXTERNAL_STORAGE` access.

## Current scope

The editor is a lightweight monospace text editor. Syntax highlighting, multi-tab editing, nested project navigation and full relative-resource preview are not implemented yet. The WebView preview is best suited to self-contained HTML documents at this stage.
